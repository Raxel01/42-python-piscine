<!-- How to use this package and what's is used for ! -->
The current Name : ft_package will be renamed once the package have other futures implemented in
this package contain for now one Module called count_in_list a basic function that count occurence of a search_for elemnts with type any  in a iterbale list width some special case also tat will be handled

you can check count_in_list.__doc__ for more details
this package is started in 08-11-2024 - 2:41 as a school project this will maybe be developed to full fill
some developer needs by providing some repetitive logics when coding all this is to make your life easy
wen Coding so think once to use us think twice code once

happy Coding :)

